# WinFuncs Library #
## What is this? ##
Simplifying various WinAPI functions, with this library you won`t need to use ctypes to call WinAPI functions.
## Working with the library ##


