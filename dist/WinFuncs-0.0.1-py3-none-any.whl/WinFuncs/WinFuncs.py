def hi(name):
    print(f'Hello {name}')